namespace eval util {proc hello {} {return "util.tcl : bonjour"}}
