puts "main.tcl : [file tail [file dirname [info script]]]/[file tail [info script]]"
source [file join [file dirname [info script]] lib/util.tcl]
puts [util::hello]
return "fin de main.tcl"
puts "jamais"
